function [recovered_system,modes,eigenvalues,psi,b] = discrete_DMD(data)
%%
% Implement DMD
% data: n*m matrix, where n is the #data of
%       each snapshot and m is the #snapshots taken. (each column is a
%       snapshot)
% t : time of snapshots
% dt : time step for taking snapshots

%% Implementation
%
% assemble matrix
%
M = size(data,2);
N = size(data,1);
recovered_system = zeros(N,M);
previous_snapshots = data(:,1:M-1);
current_snapshot = data(:,2:M);
%
% singular value decompostion
%
[U,S,V] = svd(previous_snapshots,'econ');
%
% ignore meaningless terms
%
U = U(:,1:M-1); 
S = S(1:M-1,:);
%
% solve
%
temp_S = U' * current_snapshot * V / S;
[right_eigenvectors,D] = eig(temp_S);
eigenvalues = eig(temp_S);

psi = U * right_eigenvectors;
b = psi \ data(:,1);

recovered_system(:,1) = data(:,1);
for j = 2:M
   recovered_system(:,j) = psi * D.^(j-1) * b;
end
modes = psi;

end