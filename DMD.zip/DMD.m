X = load('vorticity.mat');
X = X.VORTALL;

data = X(:,1:91);

nx=199;
ny=449;

[recovered_system,modes,eigenvalues,psi,b] = discrete_DMD(data);

toterror = 0;
for k = 2:151
   toterror(k) = max(abs(psi*diag(eigenvalues).^(k-1)*b-X(:,k))) ;
end
plot(toterror);
